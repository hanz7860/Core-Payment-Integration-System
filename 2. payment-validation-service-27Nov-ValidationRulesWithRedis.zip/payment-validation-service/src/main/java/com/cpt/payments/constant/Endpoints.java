package com.cpt.payments.constant;

public class Endpoints {
	
	public static final String V1_PAYMENTS = "/v1/payments";
	
	private Endpoints() {}

}
