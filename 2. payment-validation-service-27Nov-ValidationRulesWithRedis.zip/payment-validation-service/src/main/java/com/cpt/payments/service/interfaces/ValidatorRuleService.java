package com.cpt.payments.service.interfaces;

public interface ValidatorRuleService {

	boolean reloadValidationRulesAndParams();

}
