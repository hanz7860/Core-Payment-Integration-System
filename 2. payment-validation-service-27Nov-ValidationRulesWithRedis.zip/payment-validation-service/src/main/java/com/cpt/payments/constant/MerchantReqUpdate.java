package com.cpt.payments.constant;

public enum MerchantReqUpdate {
	
	SAVED, DUPLICATE, ERROR;

}
