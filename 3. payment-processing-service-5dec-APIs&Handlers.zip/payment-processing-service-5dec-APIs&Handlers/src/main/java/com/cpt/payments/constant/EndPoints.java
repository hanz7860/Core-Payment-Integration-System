package com.cpt.payments.constant;

public class EndPoints {
	
	private EndPoints() {}
	
	public static final String V1_PAYMENTS = "/v1/payments";

}
