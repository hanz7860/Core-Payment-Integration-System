package com.mycomp.myfirstapp.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mycomp.myfirstapp.pojo.AddReq;
import com.mycomp.myfirstapp.service.CalculatorService;

@RestController
public class CalculatorController {

	// Define SLF4j logger for this class using logback
	private static final Logger logger = LoggerFactory.getLogger(CalculatorController.class);

	private CalculatorService calculatorService;
	
	private ApplicationContext applicationContext;
	
	public CalculatorController(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
        logger.info("CalculatorController instance created, applicationContext: {}", 
        		applicationContext);
	}
	
	@PostMapping("/add")
	public int addNumbers(@RequestBody AddReq addReq) {
		logger.info("Received request addReq: {}", addReq);

		calculatorService = applicationContext.getBean(CalculatorService.class);
		
		String[] beanNames = applicationContext.getBeanDefinitionNames();
		for (String beanName : beanNames) {
			logger.info("Bean name: {}", beanName);
		}
		
		int sum = calculatorService.addNumbers(addReq);
		
		logger.info("Received from service, sum: {}", sum);
		return sum;
	}
}
