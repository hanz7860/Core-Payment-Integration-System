package com.mycomp.myfirstapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstAppProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstAppProjApplication.class, args);
	}

}
