package com.mycomp.myfirstapp.service;

import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.mycomp.myfirstapp.pojo.AddReq;

@Service
public class CalculatorService {
	
	private Random random;
	
	private Gson gson;
	
	public CalculatorService(Random random, 
			Gson gson) {
		this.random = random;
		this.gson = gson;
	}
	
	// write slf4j logger for this class using logback
	private static final Logger logger = LoggerFactory.getLogger(CalculatorService.class);
	
	public int addNumbers(AddReq addReq) {
		
		logger.info("Received request to add numbers addReq: {}", addReq);
		
		int sum = addReq.getNum1() + addReq.getNum2();
		
		
		int randInt = random.nextInt(100);
		
		logger.info("Random number: {}", randInt);
		
		
		
		String json = gson.toJson(addReq);
		
		logger.info("JSON: {}", json);
		
		
		logger.info("Calculated sum: {}", sum);
		return sum;
	}

}
